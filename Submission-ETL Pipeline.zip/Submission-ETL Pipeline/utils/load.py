import pandas as pd
from sqlalchemy import create_engine
import logging
from google.oauth2.service_account import Credentials
from googleapiclient.discovery import build
from googleapiclient.errors import HttpError

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler()]
)

# Google Sheets Configuration
SERVICE_ACCOUNT_FILE = './google-sheets-api.json'
SCOPES = ['https://www.googleapis.com/auth/spreadsheets']
SPREADSHEET_ID = '1W-PnZls_39Ofylg6n7TBOcQVnNF7wdqQxpgYsTm77yU'
DEFAULT_SHEET_NAME = 'Sheet1'

class GoogleSheetsLoader:
    def __init__(self):
        try:
            self.credentials = Credentials.from_service_account_file(
                SERVICE_ACCOUNT_FILE, 
                scopes=SCOPES
            )
            self.service = build('sheets', 'v4', credentials=self.credentials)
        except Exception as e:
            logging.error(f"Failed to initialize Google Sheets client: {e}")
            raise

    def save_to_sheets(self, df, sheet_name=DEFAULT_SHEET_NAME, start_cell='A2'):
        """Save DataFrame to Google Sheets"""
        try:
            # Convert DataFrame to list of lists
            values = [df.columns.values.tolist()] + df.values.tolist()
            
            body = {
                'values': values
            }
            
            # Determine the last column letter based on DataFrame columns count
            last_col_index = len(df.columns) - 1
            last_col_letter = chr(ord('A') + last_col_index) if last_col_index < 26 else None
            if last_col_letter is None:
                # For columns beyond 'Z', use 'Z' as a fallback (could be improved)
                last_col_letter = 'Z'
            
            # Clear existing data first with corrected range
            clear_range = f"{sheet_name}!{start_cell}:{last_col_letter}"
            self.service.spreadsheets().values().clear(
                spreadsheetId=SPREADSHEET_ID,
                range=clear_range,
            ).execute()
            
            # Update with new data
            result = self.service.spreadsheets().values().update(
                spreadsheetId=SPREADSHEET_ID,
                range=f"{sheet_name}!{start_cell}",
                valueInputOption='RAW',
                body=body
            ).execute()
            
            logging.info(f"Successfully saved {len(values)} rows to Google Sheets")
            return True
            
        except HttpError as error:
            logging.error(f"Google Sheets API error: {error}")
            return False
        except Exception as e:
            logging.error(f"Failed to save to Google Sheets: {e}")
            return False

def save_to_csv(df, filepath='products.csv'):
    """Save DataFrame to CSV"""
    try:
        df.to_csv(filepath, index=False)
        logging.info(f"Data successfully saved to CSV: {filepath}")
        return True
    except Exception as e:
        logging.error(f"Failed to save data to CSV: {e}")
        return False

def save_to_postgresql(df, db_url, table_name='fashion_products'):
    """Save DataFrame to PostgreSQL database"""
    try:
        engine = create_engine(db_url)
        df.to_sql(
            name=table_name,
            con=engine,
            if_exists='replace',
            index=False
        )
        logging.info(f"Data successfully saved to PostgreSQL table: {table_name}")
        return True
    except Exception as e:
        logging.error(f"Failed to save data to PostgreSQL: {e}")
        return False

def load_data(df, output_format='csv', **kwargs):
    """
    Main load function that handles multiple output formats
    
    Parameters:
    - df: DataFrame to save
    - output_format: 'csv', 'postgresql', or 'sheets'
    - kwargs:
        For CSV: filepath (optional)
        For PostgreSQL: db_url, table_name (optional)
        For Sheets: sheet_name, start_cell (optional)
    """
    if output_format == 'csv':
        return save_to_csv(df, kwargs.get('filepath', 'products.csv'))
    elif output_format == 'postgresql':
        return save_to_postgresql(
            df, 
            kwargs['db_url'], 
            kwargs.get('table_name', 'fashion_products')
        )
    elif output_format == 'sheets':
        sheets_loader = GoogleSheetsLoader()
        return sheets_loader.save_to_sheets(
            df,
            kwargs.get('sheet_name', DEFAULT_SHEET_NAME),
            kwargs.get('start_cell', 'A2')
        )
    else:
        raise ValueError("Invalid output format. Choose 'csv', 'postgresql', or 'sheets'")
