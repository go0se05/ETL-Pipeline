import pandas as pd
import numpy as np

def create_dataframe(data):
    """Create DataFrame with proper data types"""
    if data is None:
        raise ValueError("Input data cannot be None")
    
    df = pd.DataFrame(data)
    
    # Set string columns efficiently
    str_cols = ['Title', 'Price', 'Rating', 'Colors', 'Size', 'Gender', 'Timestamp']
    df[str_cols] = df[str_cols].astype('string')
    
    return df

def convert_to_rupiah(s, rate=16000):
    """Convert price to Rupiah"""
    return s * rate

def clean_column(df, column, operations):
    """Generic column cleaner with chained operations"""
    try:
        for op in operations:
            df[column] = op(df[column])
        return df
    except Exception as e:
        raise ValueError(f"Error cleaning {column}: {str(e)}")

def clean_title(s):
    """Title cleaning operations"""
    s = s.str.strip()
    return s.replace(['', 'Unknown Product'], pd.NA)

def clean_price(s):
    """Price cleaning operations"""
    s = s.str.strip()
    s = s.replace('Price Unavailable', pd.NA)
    return pd.to_numeric(
        s.str.replace(r'[\$,]', '', regex=True).str.replace(',', '.'), 
        errors='coerce'
    )

def clean_rating(s):
    """Rating cleaning operations"""
    s = s.str.strip()
    s = s.replace('Rating: ⭐ Invalid Rating / 5', pd.NA)
    return pd.to_numeric(s.str.extract(r'(\d+(\.\d+)?)', expand=False)[0], errors='coerce')

def clean_colors(s):
    """Colors cleaning operations"""
    return pd.to_numeric(s.str.extract(r'(\d+)', expand=False), errors='coerce')

def extract_category(s, prefix):
    """Generic extractor for Size/Gender columns"""
    s = s.str.extract(fr'{prefix}:\s*(\w+)', expand=False)
    return s.fillna(pd.NA).astype('string')

def format_timestamp(s):
    """Timestamp formatting"""
    s = pd.to_datetime(s, errors='coerce')
    return s.dt.strftime('%Y-%m-%dT%H:%M:%S.%f')

def remove_empty_rows(df, critical_cols):
    """Remove rows with NA in critical columns"""
    return df.dropna(subset=critical_cols)

def clean_data(data):
    """Optimized cleaning pipeline"""
    try:
        # Define cleaning steps for each column
        cleaning_steps = {
            'Title': [clean_title],
            'Price': [clean_price, convert_to_rupiah],
            'Rating': [clean_rating],
            'Colors': [clean_colors],
            'Size': [lambda s: extract_category(s, 'Size')],
            'Gender': [lambda s: extract_category(s, 'Gender')],
            'Timestamp': [format_timestamp]
        }
        
        # Create and clean DataFrame
        df = create_dataframe(data)
        
        # Apply all cleaning steps
        for col, steps in cleaning_steps.items():
            if col in df.columns:
                df = clean_column(df, col, steps)
        
        # Remove rows with missing critical data
        return remove_empty_rows(df, ['Title', 'Price', 'Rating'])
        
    except Exception as e:
        raise ValueError(f"Data cleaning failed: {str(e)}")