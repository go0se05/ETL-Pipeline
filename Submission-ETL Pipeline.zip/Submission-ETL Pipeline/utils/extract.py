from datetime import datetime
import time
import logging
from typing import Optional, List, Dict, Union
import requests
from bs4 import BeautifulSoup
import pandas as pd
from utils.transform import clean_data
from utils.load import load_data

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s [%(levelname)s] %(message)s',
    handlers=[logging.StreamHandler()]
)

class ProductScraper:
    """A web scraper for extracting product information from e-commerce pages."""
    
    DEFAULT_HEADERS = {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                     "(KHTML, like Gecko) Chrome/96.0.4664.110 Safari/537.36"
    }
    DEFAULT_TIMEOUT = 10
    MAX_RETRIES = 3
    RETRY_BACKOFF = 2

    def __init__(self):
        """Initialize the scraper with a requests session."""
        self.session = requests.Session()
        self.session.headers.update(self.DEFAULT_HEADERS)
        self.logger = logging.getLogger(__name__)

    def fetch_page(self, url: str) -> Optional[bytes]:
        """Fetch page content with retry logic and error handling."""
        for attempt in range(1, self.MAX_RETRIES + 1):
            try:
                response = self.session.get(url, timeout=self.DEFAULT_TIMEOUT)
                if response.status_code == 404:
                    self.logger.info(f"Page not found (404): {url}")
                    return None
                response.raise_for_status()
                return response.content
            except requests.exceptions.RequestException as e:
                self.logger.warning(f"Attempt {attempt} failed for {url}: {str(e)}")
                if attempt < self.MAX_RETRIES:
                    time.sleep(self.RETRY_BACKOFF * attempt)
        return None

    @staticmethod
    def _extract_text(element: Union[BeautifulSoup, None], default: str = "Not found") -> str:
        """Helper method to safely extract text from BeautifulSoup element."""
        return element.get_text(strip=True) if element else default

    def parse_product(self, card: BeautifulSoup) -> Dict[str, Union[str, datetime]]:
        """Extract product data from a single product card."""
        product = {
            "Title": "Not found",
            "Price": "Not found",
            "Rating": "Not found",
            "Colors": "Not found",
            "Size": "Not found",
            "Gender": "Not found",
            "Timestamp": datetime.now()
        }

        try:
            details = card.find('div', class_='product-details') or card
            product["Title"] = self._extract_text(details.find('h3', class_='product-title'))
            
            price_container = details.find('div', class_='price-container') or details
            price_element = (price_container.find('span', class_='price') or 
                           price_container.find('p', class_='price'))
            product["Price"] = self._extract_text(price_element)
            
            info_paragraphs = details.find_all('p', style='font-size: 14px; color: #777;')
            for i, field in enumerate(["Rating", "Colors", "Size", "Gender"]):
                if i < len(info_paragraphs):
                    product[field] = self._extract_text(info_paragraphs[i])
        except Exception as e:
            self.logger.error(f"Error parsing product: {str(e)}", exc_info=True)
            
        return product

    def scrape_data(self, base_url: str, start_page: int = 1, delay: float = 1.0) -> List[Dict]:
        """Scrape all products from paginated results."""
        products = []
        current_page = start_page
        has_more = True

        while has_more:
            url = f"{base_url}page{current_page}" if current_page > 1 else base_url
            self.logger.info(f"Processing page {current_page}: {url}")
            
            if not (html := self.fetch_page(url)):
                break
                
            soup = BeautifulSoup(html, 'html.parser')
            cards = soup.find_all('div', class_='collection-card')
            
            if not cards:
                self.logger.warning("No products found - ending scrape")
                break
                
            products.extend(self.parse_product(card) for card in cards)
            
            next_button = soup.find('li', class_='next')
            has_more = bool(next_button and 'disabled' not in next_button.get('class', []))
            current_page += 1 if has_more else 0
            
            # Tempatkan sleep dengan error handling di sini
            try:
                time.sleep(delay)
            except KeyboardInterrupt:
                self.logger.info("Scraping interrupted by user")
                raise
            except Exception as e:
                self.logger.warning(f"Sleep interrupted: {e}")
                continue
                
        return products