import logging
from utils.extract import ProductScraper
from utils.load import load_data
from utils.transform import clean_data

# Konfigurasi logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

def run_step(step_name, func, *args, **kwargs):
    """Running ETL steps and handling errors."""
    logging.info(f"▶️ Running steps: {step_name}...")
    try:
        result = func(*args, **kwargs)
        logging.info(f"✅ Step '{step_name}' success.\n")
        return result
    except Exception as e:
        logging.error(f"❌ Step '{step_name}' Failed: {e}\n")
        return None

def etl_pipeline():
    """Main function to run the ETL pipeline."""
    BASE_URL = 'https://fashion-studio.dicoding.dev/'
    DB_URI = 'postgresql+psycopg2://developer:123456789@localhost:5432/fashionproduct'

     # Google Sheets config
    SERVICE_ACCOUNT_FILE = './google-sheets-api.json'
    SPREADSHEET_ID = '1W-PnZls_39Ofylg6n7TBOcQVnNF7wdqQxpgYsTm77yU'

    # Inisialisasi scraper
    scraper = ProductScraper()

    # ─── Extract Data ───────────────────────────────────────────
    raw_products = run_step("Extract Data", scraper.scrape_data, BASE_URL)
    if raw_products is None:
        logging.error("Failed Extract data. Process stopped.")
        return

    # ─── Clean Data ───────────────────────────────────────────
    clean_df = run_step("Cleaning Data", clean_data, raw_products)
    if clean_df is None:
        logging.error("Failed clean data. Process stopped.")
        return

    logging.info("📊 Preview Clean Data Result:")
    logging.info(f"\n{clean_df.head()}\n")

    # ─── Load Data ───────────────────────────────────────────
    # To CSV
    run_step("Save to CSV", load_data, clean_df, 'csv', filepath='products.csv')
    
    # To PostgreSQL
    run_step("Save to PostgreSQL", load_data, clean_df, 'postgresql', 
             db_url=DB_URI, table_name='products')
    
    # To Google Sheets
    run_step("Save to Google Sheets", load_data, clean_df, 'sheets',
             service_account_file=SERVICE_ACCOUNT_FILE,
             spreadsheet_id=SPREADSHEET_ID,
             sheet_name='Sheet1',
             start_cell='A2')

if __name__ == "__main__":
    logging.info("🚀 Start ETL Pipeline...\n")
    etl_pipeline()
    logging.info("🎉 ETL Process Success.")
