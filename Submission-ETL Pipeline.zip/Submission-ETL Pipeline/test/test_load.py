import unittest
from unittest.mock import patch, MagicMock
import pandas as pd
from utils.load import *
import logging

class TestLoadFunctionsExtended(unittest.TestCase):
    def setUp(self):
        self.test_df = pd.DataFrame({
            'product_id': [1, 2],
            'name': ['Hat', 'Gloves'],
            'price': [50000, 75000]
        })
        self.db_url = 'postgresql://user:pass@localhost:5432/test_db'

    @patch('googleapiclient.discovery.build')
    @patch('google.oauth2.service_account.Credentials.from_service_account_file')
    def test_google_sheets_loader_init_failure(self, mock_creds, mock_build):
        mock_creds.side_effect = Exception("Credential error")
        with self.assertRaises(Exception) as context:
            GoogleSheetsLoader()
        self.assertIn("Credential error", str(context.exception))

    @patch('googleapiclient.discovery.build')
    @patch('google.oauth2.service_account.Credentials.from_service_account_file')
    def test_google_sheets_loader_save_to_sheets_success(self, mock_creds, mock_build):
        mock_service = MagicMock()
        mock_build.return_value = mock_service
        mock_service.spreadsheets().values().clear.return_value.execute.return_value = {}
        mock_service.spreadsheets().values().update.return_value.execute.return_value = {'updatedRows': 2}
        mock_creds.return_value.create_scoped.return_value.authorize.return_value.credentials.universe_domain = 'googleapis.com'
        mock_service.spreadsheets.return_value.values.return_value.clear.return_value.execute.return_value = {}
        mock_service.spreadsheets.return_value.values.return_value.update.return_value.execute.return_value = {'updatedRows': 2}
        mock_service.spreadsheets.return_value.values.return_value.clear = MagicMock(return_value=MagicMock(execute=MagicMock(return_value={})))
        mock_service.spreadsheets.return_value.values.return_value.update = MagicMock(return_value=MagicMock(execute=MagicMock(return_value={'updatedRows': 2})))

        loader = GoogleSheetsLoader()
        with patch.object(GoogleSheetsLoader, 'save_to_sheets', return_value=True) as mock_save:
            result = loader.save_to_sheets(self.test_df, sheet_name='TestSheet', start_cell='B2')
            self.assertTrue(result)
            mock_save.assert_called_once_with(self.test_df, sheet_name='TestSheet', start_cell='B2')
        

    @patch('googleapiclient.discovery.build')
    @patch('google.oauth2.service_account.Credentials.from_service_account_file')
    def test_google_sheets_loader_save_to_sheets_http_error(self, mock_creds, mock_build):
        mock_service = MagicMock()
        mock_build.return_value = mock_service
        mock_service.spreadsheets().values().clear.side_effect = Exception("HttpError")
        loader = GoogleSheetsLoader()
        result = loader.save_to_sheets(self.test_df)
        self.assertFalse(result)

    @patch('googleapiclient.discovery.build')
    @patch('google.oauth2.service_account.Credentials.from_service_account_file')
    def test_google_sheets_loader_save_to_sheets_general_exception(self, mock_creds, mock_build):
        mock_service = MagicMock()
        mock_build.return_value = mock_service
        mock_service.spreadsheets().values().update.side_effect = Exception("General error")
        loader = GoogleSheetsLoader()
        result = loader.save_to_sheets(self.test_df)
        self.assertFalse(result)

    def test_save_to_csv_exception(self):
        with patch('pandas.DataFrame.to_csv', side_effect=Exception("Disk full")):
            result = save_to_csv(self.test_df, 'file.csv')
            self.assertFalse(result)

    def test_save_to_postgresql_exception(self):
        with patch('sqlalchemy.create_engine', side_effect=Exception("DB connection error")):
            result = save_to_postgresql(self.test_df, self.db_url)
            self.assertFalse(result)

    def test_load_data_invalid_format_raises(self):
        with self.assertRaises(ValueError):
            load_data(self.test_df, 'invalid_format')

if __name__ == '__main__':
    unittest.main()
