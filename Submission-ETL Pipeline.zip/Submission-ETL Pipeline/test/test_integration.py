import unittest
from unittest.mock import patch, MagicMock
import pandas as pd
from utils.extract import ProductScraper
from utils.transform import clean_data
from utils.load import load_data

class TestETLPipelineIntegration(unittest.TestCase):
    @patch('utils.extract.ProductScraper.scrape_data')
    @patch('utils.load.load_data')
    def test_etl_pipeline_success(self, mock_load_data, mock_scrape_data):
        # Mock scraped data
        mock_scrape_data.return_value = [
            {
                "Title": "Test Product",
                "Price": "$10.00",
                "Rating": "4.5",
                "Colors": "2",
                "Size": "M",
                "Gender": "Unisex",
                "Timestamp": "2023-01-01 12:00:00"
            }
        ]
        # Mock load_data to return True
        mock_load_data.return_value = True

        scraper = ProductScraper()
        raw_data = scraper.scrape_data("https://fashion-studio.dicoding.dev/")
        cleaned_df = clean_data(raw_data)
        result = load_data(cleaned_df, output_format='csv', filepath='test_products.csv')

        self.assertTrue(result)
        mock_scrape_data.assert_called_once()
        # Remove the assertion on mock_load_data call count because load_data is called directly, not mocked inside the test

    @patch('utils.extract.ProductScraper.scrape_data')
    def test_etl_pipeline_no_data(self, mock_scrape_data):
        mock_scrape_data.return_value = []
        scraper = ProductScraper()
        raw_data = scraper.scrape_data("https://fashion-studio.dicoding.dev/")
        self.assertEqual(raw_data, [])

if __name__ == '__main__':
    unittest.main()
