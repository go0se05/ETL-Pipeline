import unittest
import pandas as pd
import numpy as np
from utils.transform import *

class TestDataTransformation(unittest.TestCase):
    def setUp(self):
        """Sample data for testing"""
        self.sample_data = [
            {
                "Title": "  T-Shirt Basic  ",
                "Price": "$19.99",
                "Rating": "Rating: ⭐ 4.5 / 5",
                "Colors": "3 colors",
                "Size": "Size: XL",
                "Gender": "Gender: Men",
                "Timestamp": "2023-01-01 12:00:00"
            },
            {
                "Title": "Unknown Product",
                "Price": "Price Unavailable",
                "Rating": "Rating: ⭐ Invalid Rating / 5",
                "Colors": "No colors",
                "Size": "Size: ",
                "Gender": "Gender: ",
                "Timestamp": "invalid date"
            }
        ]
        
        self.clean_df = create_dataframe(self.sample_data)

    def test_create_dataframe(self):
        """Test DataFrame creation"""
        df = create_dataframe(self.sample_data)
        self.assertIsInstance(df, pd.DataFrame)
        self.assertEqual(len(df), 2)
        
        with self.assertRaises(ValueError):
            create_dataframe(None)

    def test_convert_to_rupiah(self):
        """Test currency conversion"""
        self.assertEqual(convert_to_rupiah(10), 160000)
        self.assertEqual(convert_to_rupiah(1.5, rate=15000), 22500)

    def test_clean_title(self):
        """Test title cleaning"""
        series = pd.Series(["  Test Product  ", "", "Unknown Product", None], dtype="string")
        cleaned = clean_title(series)
        self.assertEqual(cleaned.iloc[0], "Test Product")
        self.assertTrue(pd.isna(cleaned.iloc[1]))
        self.assertTrue(pd.isna(cleaned.iloc[2]))

    def test_clean_price(self):
        """Test price cleaning"""
        series = pd.Series(["$19.99", "Price Unavailable", "1,000.50", "invalid"], dtype="string")
        cleaned = clean_price(series)
        self.assertAlmostEqual(cleaned.iloc[0], 19.99)
        self.assertTrue(pd.isna(cleaned.iloc[1]))
        self.assertAlmostEqual(cleaned.iloc[2], 1000.50)
        self.assertTrue(pd.isna(cleaned.iloc[3]))

    def test_clean_rating(self):
        """Test rating cleaning"""
        series = pd.Series([
            "Rating: ⭐ 4.5 / 5", 
            "Rating: ⭐ Invalid Rating / 5", 
            "4.2 stars"
        ], dtype="string")
        cleaned = clean_rating(series)
        self.assertAlmostEqual(cleaned.iloc[0], 4.5)
        self.assertTrue(pd.isna(cleaned.iloc[1]))
        self.assertAlmostEqual(cleaned.iloc[2], 4.2)

    def test_clean_colors(self):
        """Test colors cleaning"""
        series = pd.Series(["3 colors", "No colors", "5"], dtype="string")
        cleaned = clean_colors(series)
        self.assertEqual(cleaned.iloc[0], 3)
        self.assertTrue(pd.isna(cleaned.iloc[1]))
        self.assertEqual(cleaned.iloc[2], 5)

    def test_extract_category(self):
        """Test category extraction"""
        size_series = pd.Series(["Size: XL", "Size: ", None], dtype="string")
        gender_series = pd.Series(["Gender: Men", "Gender: ", ""], dtype="string")
        
        sizes = extract_category(size_series, "Size")
        genders = extract_category(gender_series, "Gender")
        
        self.assertEqual(sizes.iloc[0], "XL")
        self.assertTrue(pd.isna(sizes.iloc[1]))
        self.assertTrue(pd.isna(sizes.iloc[2]))
        
        self.assertEqual(genders.iloc[0], "Men")
        self.assertTrue(pd.isna(genders.iloc[1]))
        self.assertTrue(pd.isna(genders.iloc[2]))

    def test_format_timestamp(self):
        """Test timestamp formatting"""
        series = pd.Series([
            "2023-01-01 12:00:00",
            "invalid date",
            None
        ], dtype="string")
        
        formatted = format_timestamp(series)
        self.assertEqual(formatted.iloc[0], "2023-01-01T12:00:00.000000")
        self.assertTrue(pd.isna(formatted.iloc[1]))
        self.assertTrue(pd.isna(formatted.iloc[2]))

    def test_remove_empty_rows(self):
        """Test empty row removal"""
        df = pd.DataFrame({
            "Title": ["A", None, "C"],
            "Price": [10, 20, None],
            "Rating": [1, 2, 3]
        })
        
        cleaned = remove_empty_rows(df, ["Title", "Price"])
        self.assertEqual(len(cleaned), 1)
        self.assertEqual(cleaned.iloc[0]["Title"], "A")

    def test_clean_data_integration(self):
        """Test full cleaning pipeline"""
        cleaned = clean_data(self.sample_data)
        
        # Verify structure
        self.assertIsInstance(cleaned, pd.DataFrame)
        self.assertEqual(len(cleaned), 1)  # One row should be removed
        
        # Verify transformations
        row = cleaned.iloc[0]
        self.assertEqual(row["Title"], "T-Shirt Basic")
        self.assertAlmostEqual(row["Price"], 19.99 * 16000)  # Rupiah conversion
        self.assertAlmostEqual(row["Rating"], 4.5)
        self.assertEqual(row["Colors"], 3)
        self.assertEqual(row["Size"], "XL")
        self.assertEqual(row["Gender"], "Men")
        self.assertEqual(row["Timestamp"], "2023-01-01T12:00:00.000000")
        
        # Test with empty data
        with self.assertRaises(ValueError):
            clean_data([])

    def test_error_handling(self):
        """Test error cases"""
        # Test invalid column cleaning
        df = create_dataframe(self.sample_data)
        with self.assertRaises(ValueError):
            clean_column(df, "Invalid_Column", [lambda x: x])
            
        # Test invalid operations
        with self.assertRaises(ValueError):
            clean_column(df, "Title", [lambda x: x / 0])  # Division by zero

if __name__ == "__main__":
    unittest.main()