import unittest
from unittest.mock import patch, MagicMock
import pandas as pd
from datetime import datetime
from main import run_step, etl_pipeline
from utils.extract import ProductScraper
from utils.transform import clean_data
from utils.load import load_data

class TestETLPipeline(unittest.TestCase):
    
    @patch('utils.extract.ProductScraper.scrape_data')
    def test_extract_step(self, mock_scrape):
        # Mock data extraction
        mock_scrape.return_value = [
            {
                "Title": "Test Product",
                "Price": "$10.99",
                "Rating": "Rating: ⭐ 4.5 / 5",
                "Colors": "5 colors",
                "Size": "Size: L",
                "Gender": "Gender: Men",
                "Timestamp": datetime.now()
            }
        ]
        
        result = run_step("Test Extract", mock_scrape, "http://test.url")
        self.assertIsNotNone(result)
        self.assertEqual(len(result), 1)
        self.assertEqual(result[0]["Title"], "Test Product")

    def test_transform_step(self):
        # Test data cleaning
        raw_data = [
            {
                "Title": "  Test Product  ",
                "Price": "$10.99",
                "Rating": "Rating: ⭐ 4.5 / 5",
                "Colors": "5 colors",
                "Size": "Size: L",
                "Gender": "Gender: Men",
                "Timestamp": "2023-01-01 12:00:00"
            }
        ]
        
        cleaned_df = clean_data(raw_data)
        self.assertIsNotNone(cleaned_df)
        self.assertEqual(cleaned_df.iloc[0]["Title"], "Test Product")
        self.assertEqual(cleaned_df.iloc[0]["Price"], 10.99 * 16000)  # Check Rupiah conversion

    @patch('utils.load.save_to_csv')
    @patch('utils.load.save_to_postgresql')
    def test_load_step(self, mock_pg, mock_csv):
        # Mock load functions
        mock_csv.return_value = True
        mock_pg.return_value = True
        
        # Create test dataframe
        test_df = pd.DataFrame({
            "Title": ["Product A"],
            "Price": [100000],
            "Rating": [4.5],
            "Colors": [3],
            "Size": ["L"],
            "Gender": ["Men"],
            "Timestamp": ["2023-01-01T12:00:00"]
        })
        
        # Test CSV save
        csv_result = run_step("Test CSV Save", load_data, test_df, 'csv', filepath='test.csv')
        self.assertTrue(csv_result)
        
        # Test PostgreSQL save
        pg_result = run_step("Test PG Save", load_data, test_df, 'postgresql', 
                            db_url='postgresql://test', table_name='test')
        self.assertTrue(pg_result)

    @patch('main.run_step')
    def test_full_pipeline(self, mock_run_step):
        # Mock all steps to return success
        mock_run_step.side_effect = [
            [{"Title": "Test"}],  # Extract
            pd.DataFrame({"Title": ["Test"]}),  # Transform
            True,  # CSV Load
            True,  # PG Load
            True   # Google Sheets
        ]
        
        with self.assertLogs(level='INFO') as log:
            etl_pipeline()
            self.assertTrue(any("📊 Preview Clean Data Result:" in message for message in log.output))

    def test_error_handling(self):
        # Test error handling in run_step
        def failing_function():
            raise ValueError("Test error")
            
        with self.assertLogs(level='ERROR') as log:
            result = run_step("Test Failure", failing_function)
            self.assertIsNone(result)
            self.assertIn("Step 'Test Failure' Failed", log.output[0])

    @patch('main.run_step')
    def test_load_google_sheets(self, mock_run_step):
        # Test the Google Sheets load step specifically
        mock_run_step.side_effect = [
            True  # Simulate success for Google Sheets load
        ]
        with self.assertLogs(level='INFO') as log:
            # Call run_step directly for Google Sheets load
            result = run_step("Save to Google Sheets", lambda: True)
            self.assertTrue(result)
            self.assertIn("✅ Step 'Save to Google Sheets' success.", log.output[1])

    def test_etl_pipeline_extract_fail(self):
        with patch('utils.extract.ProductScraper.scrape_data', return_value=None):
            with self.assertLogs(level='ERROR') as log:
                etl_pipeline()
                self.assertIn("Failed Extract data. Process stopped.", log.output[-1])

    def test_etl_pipeline_clean_fail(self):
        with patch('utils.extract.ProductScraper.scrape_data', return_value=[{"Title": "Test"}]):
            with patch('utils.transform.clean_data', return_value=None):
                with self.assertLogs(level='ERROR') as log:
                    etl_pipeline()
                    self.assertIn("Failed clean data. Process stopped.", log.output[-1])

if __name__ == "__main__":
    unittest.main()
