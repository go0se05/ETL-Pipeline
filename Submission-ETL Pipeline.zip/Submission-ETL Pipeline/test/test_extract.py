import unittest
from unittest.mock import patch, MagicMock
from utils.extract import ProductScraper
from bs4 import BeautifulSoup
import datetime
import requests

class TestProductScraper(unittest.TestCase):
    def setUp(self):
        self.scraper = ProductScraper()

    def test_extract_text_with_element(self):
        html = BeautifulSoup("<span>Test Text</span>", "html.parser")
        text = self.scraper._extract_text(html.span)
        self.assertEqual(text, "Test Text")

    def test_extract_text_with_none(self):
        text = self.scraper._extract_text(None)
        self.assertEqual(text, "Not found")

    def test_parse_product_minimal_valid_html(self):
        html = """
        <div class="product-details">
            <h3 class="product-title">Cool Jacket</h3>
            <div class="price-container"><span class="price">$29.99</span></div>
            <p style="font-size: 14px; color: #777;">4.5</p>
            <p style="font-size: 14px; color: #777;">3 Colors</p>
            <p style="font-size: 14px; color: #777;">M</p>
            <p style="font-size: 14px; color: #777;">Unisex</p>
        </div>
        """
        soup = BeautifulSoup(html, "html.parser")
        result = self.scraper.parse_product(soup)

        self.assertEqual(result['Title'], 'Cool Jacket')
        self.assertEqual(result['Price'], '$29.99')
        self.assertEqual(result['Rating'], '4.5')
        self.assertEqual(result['Colors'], '3 Colors')
        self.assertEqual(result['Size'], 'M')
        self.assertEqual(result['Gender'], 'Unisex')
        self.assertIsInstance(result['Timestamp'], datetime.datetime)

    @patch('utils.extract.requests.Session.get')
    def test_fetch_page_success(self, mock_get):
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = b"<html></html>"
        mock_get.return_value = mock_response

        url = "https://fashion-studio.dicoding.dev/"
        content = self.scraper.fetch_page(url)
        self.assertEqual(content, b"<html></html>")

    @patch('utils.extract.requests.Session.get')
    def test_fetch_page_404(self, mock_get):
        mock_response = MagicMock()
        mock_response.status_code = 404
        mock_get.return_value = mock_response

        url = "https://fashion-studio.dicoding.dev/page999"
        content = self.scraper.fetch_page(url)
        self.assertIsNone(content)

    @patch('utils.extract.time.sleep', return_value=None)
    @patch('utils.extract.requests.Session.get')
    def test_fetch_page_retry(self, mock_get, mock_sleep):
        # Simulate failures for first two attempts, success on third
        mock_response_fail = MagicMock()
        mock_response_fail.status_code = 500
        mock_response_fail.raise_for_status.side_effect = Exception("Server error")

        mock_response_success = MagicMock()
        mock_response_success.status_code = 200
        mock_response_success.content = b"<html></html>"
        mock_response_success.raise_for_status.return_value = None

        def side_effect(*args, **kwargs):
            if side_effect.call_count == 0:
                side_effect.call_count += 1
                raise requests.exceptions.Timeout("Timeout")
            elif side_effect.call_count == 1:
                side_effect.call_count += 1
                # Do not raise exception here, just return the mock response
                # Also clear the side effect to prevent raising exception
                mock_response_fail.raise_for_status.side_effect = None
                mock_response_fail.content = b"<html></html>"
                # Simulate retry by raising exception on first call, then success on second call
                raise requests.exceptions.Timeout("Timeout")
            else:
                return mock_response_success
        side_effect.call_count = 0

        mock_get.side_effect = side_effect

        url = "https://fashion-studio.dicoding.dev/"
        content = self.scraper.fetch_page(url)
        self.assertEqual(content, b"<html></html>")
        self.assertEqual(mock_get.call_count, 3)

    def test_parse_product_error_handling(self):
        # Pass a BeautifulSoup object that will cause an exception in parse_product
        class BadCard:
            def find(self, *args, **kwargs):
                raise Exception("Test exception")

        bad_card = BadCard()
        result = self.scraper.parse_product(bad_card)
        self.assertEqual(result["Title"], "Not found")
        self.assertEqual(result["Price"], "Not found")

    @patch('utils.extract.requests.Session.get')
    @patch('utils.extract.time.sleep', return_value=None)
    def test_scrape_data_no_products(self, mock_sleep, mock_get):
        # Simulate a page with no products
        html = b"<html><body><div>No products here</div></body></html>"
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.content = html
        mock_get.return_value = mock_response

        result = self.scraper.scrape_data("https://fashion-studio.dicoding.dev/")
        self.assertEqual(result, [])

if __name__ == '__main__':
    unittest.main()
